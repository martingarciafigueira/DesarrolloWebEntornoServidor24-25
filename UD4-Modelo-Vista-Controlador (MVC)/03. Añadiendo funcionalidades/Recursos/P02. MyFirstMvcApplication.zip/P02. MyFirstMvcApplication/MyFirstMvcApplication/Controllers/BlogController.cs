﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using MyFirstMvcApplication.Models;

namespace MyFirstMvcApplication.Controllers
{
    public class BlogController : Controller
    {
        public BlogController()
        {
            Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = new CultureInfo("en");
        } 

        //
        // GET: /Blog/
        public ActionResult Index()
        {
            using (var manager = new BlogManager())
            {
                var posts = manager.GetLatestPosts(10); // 10 latests posts
                return View(posts);
            }
        }

        // 
        // GET /Blog/Archive/2005/3 
        public ActionResult Archive(int year, int month)
        {
            using (var manager = new BlogManager())
            {
                var posts = manager.GetPostsByDate(year, month);
                return View(posts);
            }
        }

        //
        // GET /Blog/Hello-world
        public ActionResult ViewPost(string code)
        {
            using (var manager = new BlogManager())
            {
                var post = manager.GetPost(code);
                if (post == null)
                    return HttpNotFound();
                else
                    return View(post);
            }
        }
        public ActionResult ArchiveIndex()
        {
            using (var manager = new BlogManager())
            {
                var archiveIndex = manager.GetArchiveIndex();
                return View(archiveIndex);
            }
        }

    }
}