﻿using System.Data.Entity;

namespace MyFirstMvcApplication.Models
{
    public class BlogContext : DbContext
    {
        public BlogContext(): base("DefaultConnection") { }
        public DbSet<Post> Posts { get; set; }
    }
}