﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyFirstMvcApplication.Models
{
    public class ArchiveEntry
    {
        public int Year { get; set; }
        public int Month { get; set; }
        public int PostCount { get; set; }
    }
}