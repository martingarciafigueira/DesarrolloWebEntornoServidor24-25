﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;

namespace MyFirstMvcApplication.Models
{
    public class BlogManager : IDisposable
    {
        BlogContext _data = new BlogContext();
        public IEnumerable<Post> GetLatestPosts(int max)
        {
            var posts = from post in _data.Posts
                        orderby post.Date descending
                        select post;

            return posts.Take(max).ToList();
        }
        public IEnumerable<Post> GetPostsByDate(int year, int month)
        {
            var posts = from post in _data.Posts
                        where post.Date.Month == month && post.Date.Year == year
                        orderby post.Date descending
                        select post;

            return posts.ToList();
        }
        public Post GetPost(string code)
        {
            return _data.Posts.Include(p=>p.Comments).FirstOrDefault(post => post.Code == code);
        }

        public IEnumerable<ArchiveEntry> GetArchiveIndex()
        {
            var d = from post in _data.Posts
                    group post by new { post.Date.Year, post.Date.Month } into p
                    orderby p.Key.Year descending, p.Key.Month descending
                    select new ArchiveEntry { Month = p.Key.Month, Year = p.Key.Year, PostCount = p.Count() };
            return d.ToList();
        }

        public void Dispose()
        {
            _data.Dispose();
        }
    }
}