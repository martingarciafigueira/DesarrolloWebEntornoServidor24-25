﻿using System;
using System.Data.Entity;

namespace MyFirstMvcApplication.Models
{
    public class BlogInitializer : DropCreateDatabaseIfModelChanges<BlogContext>
    {
        protected override void Seed(BlogContext context)
        {
            context.Posts.Add(new Post()
            {
                Author = "José M. Aguilar",
                Title = "Hello, world!",
                Code = "hello-world",
                Date = new DateTime(2005, 8, 12),
                Text = "Hi, everybody, this is my first blog post!",
                Comments = new[]
                {
                    new Comment() { Author = "John Doe", Date = new DateTime(2005, 8,13), Text="Hey, this is great!" },
                    new Comment() { Author = "Peter Petersen", Date = new DateTime(2005, 8,14), Text="Good news! Keep writing, please :)" }
                }
            });
            context.Posts.Add(new Post()
            {
                Author = "José M. Aguilar",
                Title = "Second post",
                Code = "second-post",
                Date = new DateTime(2005, 8, 22),
                Text = "Well, it's time to start writing... :)",
                Comments = new[]
                            {
                                new Comment() { Author = "Ramiro Law", Date = new DateTime(2005, 8, 23), Text = "Which topic are you considering?" },
                                new Comment() { Author = "José M. Aguilar", Date = new DateTime(2005, 8, 24), Text = "In fact, I don't know yet :(" }
                            }
            });
            context.Posts.Add(new Post()
            {
                Author = "José M. Aguilar",
                Title = "Today is my birthday",
                Code = "today-is-my-birthday",
                Date = new DateTime(2005, 9, 1),
                Text = "Today is my birthday! I accept gifts ;)",
                Comments = new[]
                            {
                                new Comment() { Author = "Phil Newton", Date = new DateTime(2005, 9, 1), Text = "Happy birthday, man!" }
                            }
            });
            base.Seed(context);
        }
    }
}