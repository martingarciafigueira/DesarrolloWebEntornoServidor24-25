﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(MyFirstMvcApplication.Startup))]
namespace MyFirstMvcApplication
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
